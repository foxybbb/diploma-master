var files_dup =
[
    [ "doc", "dir_e68e8157741866f444e17edd764ebbae.html", "dir_e68e8157741866f444e17edd764ebbae" ],
    [ "sdk", "dir_243a4ba6b4f893d71afbb5a3e90552fa.html", "dir_243a4ba6b4f893d71afbb5a3e90552fa" ]
];