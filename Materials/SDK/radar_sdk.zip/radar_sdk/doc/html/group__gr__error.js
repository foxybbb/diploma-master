var group__gr__error =
[
    [ "ifx_error_clear", "group__gr__error.html#ga9cc18db3af45b6a1651521e2d99e5af8", null ],
    [ "ifx_error_get", "group__gr__error.html#ga7d3ea53a4f5ff1a3e81a825c127ec6c9", null ],
    [ "ifx_error_get_and_clear", "group__gr__error.html#ga82343dadb904b08049ab03d636453e62", null ],
    [ "ifx_error_is_set", "group__gr__error.html#ga0624221d7666a2c95b2106b539a1ff4a", null ],
    [ "ifx_error_set_callback", "group__gr__error.html#ga5bedb9b329a42c169a718d1176b943a4", null ],
    [ "ifx_error_set_internal", "group__gr__error.html#ga15624d5169f74e43067151340069bc2e", null ],
    [ "ifx_error_set_no_callback", "group__gr__error.html#ga19265805898cc9f2cbfe014c3a68e440", null ],
    [ "ifx_error_to_string", "group__gr__error.html#gae9067f7d71578c4643bd9b45039d23b7", null ]
];