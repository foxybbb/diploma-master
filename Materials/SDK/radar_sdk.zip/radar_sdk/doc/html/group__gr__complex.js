var group__gr__complex =
[
    [ "ifx_complex_abs", "group__gr__complex.html#ga3cdb190e207e0f58be169cc6b4872b1a", null ],
    [ "ifx_complex_add", "group__gr__complex.html#ga8c5f62c7c468d484270f8e2e433dd8c9", null ],
    [ "ifx_complex_add_real", "group__gr__complex.html#ga1371b4164a655bfa8a9d809d6b24da62", null ],
    [ "ifx_complex_arg", "group__gr__complex.html#gae3719a9f4e697e7c9e216615ee031574", null ],
    [ "ifx_complex_conj", "group__gr__complex.html#ga0669a535edaab8aa1954d8547917ad40", null ],
    [ "ifx_complex_div", "group__gr__complex.html#ga18a1a1e7fa7185f4349fe728d54c69b0", null ],
    [ "ifx_complex_div_real", "group__gr__complex.html#gaff8a184178b88affd429db5977816d65", null ],
    [ "ifx_complex_from_polar", "group__gr__complex.html#ga26a23d9680f151cbeaed3b39cc829c0a", null ],
    [ "ifx_complex_ln", "group__gr__complex.html#ga52a41844d44f7a91800de2e3ef90bbf8", null ],
    [ "ifx_complex_log10", "group__gr__complex.html#ga88bea1ffb6c5ec456afc2fb90015cdc1", null ],
    [ "ifx_complex_mul", "group__gr__complex.html#ga991a7dba60271e4e674cfe2394a3059d", null ],
    [ "ifx_complex_mul_real", "group__gr__complex.html#gae1c0df96a56e909e27ca4a24fcf42bbe", null ],
    [ "ifx_complex_pow", "group__gr__complex.html#gaa9b0bb32770d962578426749b3007512", null ],
    [ "ifx_complex_sqnorm", "group__gr__complex.html#gad169a8357d88192657ba9296c0974cc0", null ],
    [ "ifx_complex_sqrt", "group__gr__complex.html#ga3bd3121eea8afef95004753a470ad75f", null ],
    [ "ifx_complex_square", "group__gr__complex.html#ga8db45393359253cf8fc44a4b0d434b89", null ],
    [ "ifx_complex_sub", "group__gr__complex.html#ga426f62239bfda6ef2682ef35a5d5c68f", null ],
    [ "ifx_complex_sub_real", "group__gr__complex.html#gafc5fd53872f8f58cb5779b31513bbb11", null ],
    [ "ifx_complex_to_polar", "group__gr__complex.html#gaf52df499602b563395ccfab0e69d868e", null ]
];