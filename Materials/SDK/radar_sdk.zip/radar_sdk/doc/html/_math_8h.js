var _math_8h =
[
    [ "ifx_Math_Axis_Spec_s", "structifx___math___axis___spec__s.html", "structifx___math___axis___spec__s" ],
    [ "ifx_Math_Axis_Spec_t", "_math_8h.html#ad69899998f5f0b38193501396518f022", null ],
    [ "ifx_Math_Scale_Type_t", "_math_8h.html#a327f1341dcd2d0c8efb67765187d63c2", [
      [ "IFX_SCALE_TYPE_LINEAR", "_math_8h.html#a327f1341dcd2d0c8efb67765187d63c2a781e3ad093c231d05c584cc1d50e26eb", null ],
      [ "IFX_SCALE_TYPE_DECIBEL_10LOG", "_math_8h.html#a327f1341dcd2d0c8efb67765187d63c2a3ccd50fdc0313b0e3b8a2297c3cc8f54", null ],
      [ "IFX_SCALE_TYPE_DECIBEL_20LOG", "_math_8h.html#a327f1341dcd2d0c8efb67765187d63c2a1e341958360fe40efec9d3069253e9dd", null ]
    ] ],
    [ "IFX_FUNCTION_DEPRECATED", "group__gr__math.html#ga97af1b536c500aa8a862768612822b26", null ],
    [ "IFX_FUNCTION_DEPRECATED", "group__gr__math.html#ga59f66332fb467e6604c1a5497d471f95", null ],
    [ "IFX_FUNCTION_DEPRECATED", "group__gr__math.html#gae73a757b1560947a0d2d838c1b4b7489", null ],
    [ "IFX_FUNCTION_DEPRECATED", "group__gr__math.html#ga7ea9600a78fc99de7fea686ba187df26", null ],
    [ "ifx_math_abs_r", "group__gr__math.html#ga9bfb75e58c2e24e2065261173046cbab", null ],
    [ "ifx_math_calc_l1norm", "group__gr__math.html#gabf077cc778880e3a0899fbc5719ba536", null ],
    [ "ifx_math_db_to_linear", "group__gr__math.html#ga7e2b791eff3da1703b8e2d552097ac96", null ],
    [ "ifx_math_find_max", "group__gr__math.html#ga44066f2859b363a6ffba7aab69c1939d", null ],
    [ "ifx_math_isclose_c", "group__gr__math.html#ga773b6f79c0611359dd9a63ad1dcc0d32", null ],
    [ "ifx_math_isclose_r", "group__gr__math.html#ga596b69605753ca2b22cbd62cef439bdc", null ],
    [ "ifx_math_ispower_of_2", "group__gr__math.html#gab07e5b60f93012f05e402b85b11d2509", null ],
    [ "ifx_math_linear_to_db", "group__gr__math.html#ga1284629f988ade5e005ac8cb973639b7", null ],
    [ "ifx_math_round_up_power_of_2_uint32", "group__gr__math.html#ga4677651b27fb8392e3aacd01d22621c7", null ],
    [ "ifx_math_vec_clip_gt_threshold_r", "group__gr__math.html#ga921005e118c124e33f5a77125aa5c099", null ],
    [ "ifx_math_vec_clip_lt_threshold_r", "group__gr__math.html#gae4e672a84e7345cb8fb18ba6f0956088", null ]
];