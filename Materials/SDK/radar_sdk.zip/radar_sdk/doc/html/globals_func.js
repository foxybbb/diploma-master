var globals_func =
[
    [ "g", "globals_func.html", null ],
    [ "i", "globals_func_i.html", null ],
    [ "n", "globals_func_n.html", null ],
    [ "r", "globals_func_r.html", null ],
    [ "s", "globals_func_s.html", null ]
];