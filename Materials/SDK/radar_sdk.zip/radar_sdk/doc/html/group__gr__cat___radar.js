var group__gr__cat___radar =
[
    [ "Angle Capon", "group__gr__anglecapon.html", "group__gr__anglecapon" ],
    [ "Angle Monopulse", "group__gr__anglemonopulse.html", "group__gr__anglemonopulse" ],
    [ "DBF", "group__gr__dbf.html", "group__gr__dbf" ],
    [ "Peak Search", "group__gr__peaksearch.html", "group__gr__peaksearch" ],
    [ "Presence Sensing", "group__gr__presencesensing.html", "group__gr__presencesensing" ],
    [ "Range Angle Image", "group__gr__rai.html", "group__gr__rai" ],
    [ "Range Doppler Map", "group__gr__rdm.html", "group__gr__rdm" ],
    [ "Range Spectrum", "group__gr__rs.html", "group__gr__rs" ],
    [ "Spectrum Axis", "group__gr__sa.html", "group__gr__sa" ],
    [ "Target", "group__gr__target.html", "group__gr__target" ]
];