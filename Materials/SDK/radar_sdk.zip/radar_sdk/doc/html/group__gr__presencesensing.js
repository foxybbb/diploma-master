var group__gr__presencesensing =
[
    [ "ifx_presence_sensing_create", "group__gr__presencesensing.html#gac845c8ccec591122d055506d10b4e184", null ],
    [ "ifx_presence_sensing_destroy", "group__gr__presencesensing.html#ga6850efd168d5c6f9495d3a0474d34028", null ],
    [ "ifx_presence_sensing_get_config_defaults", "group__gr__presencesensing.html#ga97840992930da10014e40e0a1c4cc813", null ],
    [ "ifx_presence_sensing_run", "group__gr__presencesensing.html#gae256ddb1b798052d7ae0f5129115824f", null ]
];