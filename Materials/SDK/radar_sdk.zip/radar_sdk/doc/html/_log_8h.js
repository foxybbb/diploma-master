var _log_8h =
[
    [ "IFX_LOG_DEBUG", "_log_8h.html#a3d5f42309b08ff5991d271577296f8a7", null ],
    [ "IFX_LOG_ERROR", "_log_8h.html#ad36858252f7aadfca9c971e44e5ba119", null ],
    [ "IFX_LOG_INFO", "_log_8h.html#abddfa8f56bc4333ee81ebc00385402ee", null ],
    [ "IFX_LOG_WARNING", "_log_8h.html#a438c58dff69bb37fd504e1c68e2e4048", null ],
    [ "IFX_STDOUT", "_log_8h.html#a5b4882779cad38a4426e246234c551a1", null ],
    [ "ifx_Log_Severity_t", "_log_8h.html#aa600c10ee4c1b2f544c4d887aabea5f2", [
      [ "IFX_LOG_INFO", "_log_8h.html#aa600c10ee4c1b2f544c4d887aabea5f2a306e1132c93edb2afaa7fcda903ef89f", null ],
      [ "IFX_LOG_WARNING", "_log_8h.html#aa600c10ee4c1b2f544c4d887aabea5f2a62d37509d3741246f702c1713435b074", null ],
      [ "IFX_LOG_ERROR", "_log_8h.html#aa600c10ee4c1b2f544c4d887aabea5f2a9fac568845ccd6acd2d8a838cfb344fc", null ],
      [ "IFX_LOG_DEBUG", "_log_8h.html#aa600c10ee4c1b2f544c4d887aabea5f2abe36032e6f37045b4d0c8a16cf0a1437", null ]
    ] ],
    [ "ifx_log", "group__gr__log.html#gadea3ac7d04815112795fd45eaae92db9", null ]
];