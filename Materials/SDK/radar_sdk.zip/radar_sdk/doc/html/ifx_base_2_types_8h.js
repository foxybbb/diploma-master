var ifx_base_2_types_8h =
[
    [ "IFX_DLL_HIDDEN", "ifx_base_2_types_8h.html#a45278edee51302798627502a0235b269", null ],
    [ "IFX_DLL_PUBLIC", "ifx_base_2_types_8h.html#ae273b8531f3736887224fbae8275e702", null ],
    [ "IFX_FUNCTION_DEPRECATED", "ifx_base_2_types_8h.html#a44917b86db3da77e67de76b49c557ffa", null ],
    [ "IFX_LIGHT_SPEED_MPS", "ifx_base_2_types_8h.html#afa1b3277a9b147bd5426a3f4fea85884", null ],
    [ "IFX_TYPEDEF_DEPRECATED", "ifx_base_2_types_8h.html#afb63632a4137a6e8b5ebd56e78df2de0", null ],
    [ "ifx_Complex_t", "group__gr__types.html#gaeab2d3ab8cca4b10be697dab9a3dfc2c", null ],
    [ "ifx_Float_t", "ifx_base_2_types_8h.html#a39079719d81fd7bcf3cd5113a6dbe905", null ],
    [ "ifx_Polar_t", "group__gr__types.html#gaa24c2c1cc332d296371b6b2cfea0843f", null ]
];