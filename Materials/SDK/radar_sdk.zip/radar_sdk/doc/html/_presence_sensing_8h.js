var _presence_sensing_8h =
[
    [ "ifx_PresenceSensing_Config_t", "structifx___presence_sensing___config__t.html", "structifx___presence_sensing___config__t" ],
    [ "ifx_PresenceSensing_Result_t", "structifx___presence_sensing___result__t.html", "structifx___presence_sensing___result__t" ],
    [ "IFX_PRESENCE_SENSING_MIN_DETECTION_RANGE_M", "_presence_sensing_8h.html#a5a94eb6e4ea2b1e6ca7ef16d0014f3fb", null ],
    [ "ifx_PresenceSensing_ChangeCallback_t", "_presence_sensing_8h.html#ade1a13acbef5b36da2b23a5aa78a7de0", null ],
    [ "ifx_PresenceSensing_StatusCallback_t", "_presence_sensing_8h.html#aebe2fb2de2664e5966761c6b00f0fd64", null ],
    [ "ifx_PresenceSensing_t", "_presence_sensing_8h.html#af9cd709a1fb5155095706d0313bcd519", null ],
    [ "ifx_PresenceSensing_State_t", "_presence_sensing_8h.html#a33e99f12d27850649668748d3f3d470e", [
      [ "IFX_PRESENCE_SENSING_PRESENT", "_presence_sensing_8h.html#a33e99f12d27850649668748d3f3d470eab8c1b7a8b161d8b5e3e594c39136d3f3", null ],
      [ "IFX_PRESENCE_SENSING_ABSENT", "_presence_sensing_8h.html#a33e99f12d27850649668748d3f3d470eafe4939566dc25c202117bd6215bb8add", null ]
    ] ],
    [ "ifx_presence_sensing_create", "group__gr__presencesensing.html#gac845c8ccec591122d055506d10b4e184", null ],
    [ "ifx_presence_sensing_destroy", "group__gr__presencesensing.html#ga6850efd168d5c6f9495d3a0474d34028", null ],
    [ "ifx_presence_sensing_get_config_defaults", "group__gr__presencesensing.html#ga97840992930da10014e40e0a1c4cc813", null ],
    [ "ifx_presence_sensing_run", "group__gr__presencesensing.html#gae256ddb1b798052d7ae0f5129115824f", null ]
];