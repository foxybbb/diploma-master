var modules =
[
    [ "Motion Sensing (ifxAdvancedMotionSensing)", "group__gr__cat___motion_sensing.html", "group__gr__cat___motion_sensing" ],
    [ "Algorithms (ifxAlgo)", "group__gr__cat___algorithms.html", "group__gr__cat___algorithms" ],
    [ "Avian Radar Sensor (ifxAvian)", "group__gr__cat___avian.html", "group__gr__cat___avian" ],
    [ "Base (ifxBase)", "group__gr__cat___s_d_k__base.html", "group__gr__cat___s_d_k__base" ],
    [ "BGT60LTR11 Doppler Radar Sensors (ifxDopplerLTR11)", "group__gr__cat__device__ltr11.html", "group__gr__cat__device__ltr11" ],
    [ "Motion-Angle algorithm (ifxMotionAngle)", "group__gr__cat___motion_angle.html", "group__gr__cat___motion_angle" ],
    [ "Radar (ifxRadar)", "group__gr__cat___radar.html", "group__gr__cat___radar" ],
    [ "Radar Device Common (ifxDeviceCommon)", "group__gr__cat___radar___device___common.html", "group__gr__cat___radar___device___common" ],
    [ "RadarSegmentation (ifxRadarSegmentation)", "group__gr__cat___radar_segmentation.html", "group__gr__cat___radar_segmentation" ],
    [ "Recordings (ifxRecording)", "group__gr__cat___s_d_k__recording.html", "group__gr__cat___s_d_k__recording" ],
    [ "Utility functionality (ifxUtil)", "group__gr__cat___utilities.html", "group__gr__cat___utilities" ]
];