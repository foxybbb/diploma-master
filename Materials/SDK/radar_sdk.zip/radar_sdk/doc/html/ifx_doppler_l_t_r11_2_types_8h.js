var ifx_doppler_l_t_r11_2_types_8h =
[
    [ "ifx_LTR11_APRT_Factor_t", "ifx_doppler_l_t_r11_2_types_8h.html#a8ad64ce1a605f7f6a60fd4add33bdb7f", [
      [ "IFX_LTR11_APRT_FACTOR_4", "ifx_doppler_l_t_r11_2_types_8h.html#a8ad64ce1a605f7f6a60fd4add33bdb7fae9d3b85e80ba5665ec44c7a87522ba08", null ],
      [ "IFX_LTR11_APRT_FACTOR_8", "ifx_doppler_l_t_r11_2_types_8h.html#a8ad64ce1a605f7f6a60fd4add33bdb7fa71496a4dc431bd109ae7419245f1005a", null ],
      [ "IFX_LTR11_APRT_FACTOR_16", "ifx_doppler_l_t_r11_2_types_8h.html#a8ad64ce1a605f7f6a60fd4add33bdb7fa09798ba0c70ee2e88bd36606ebda7111", null ],
      [ "IFX_LTR11_APRT_FACTOR_2", "ifx_doppler_l_t_r11_2_types_8h.html#a8ad64ce1a605f7f6a60fd4add33bdb7faec3f1741cbeee2a0503764042caa3d22", null ],
      [ "IFX_LTR11_APRT_FACTOR_1", "ifx_doppler_l_t_r11_2_types_8h.html#a8ad64ce1a605f7f6a60fd4add33bdb7fa72a4864e5827558007b730d1ca4341dc", null ]
    ] ],
    [ "ifx_LTR11_Hold_Time_t", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465", [
      [ "IFX_LTR11_HOLD_TIME_MIN", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465a5d72d7e4926b5a1ad9cee5e7a81b7d5a", null ],
      [ "IFX_LTR11_HOLD_TIME_512ms", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465acb0fec451e79bfc83ea79c3eb86b86c3", null ],
      [ "IFX_LTR11_HOLD_TIME_1s", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465ae5236d76d478f2736106ca364fed144f", null ],
      [ "IFX_LTR11_HOLD_TIME_2s", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465a2a7f815574cfb56ca342cb2f469b6a46", null ],
      [ "IFX_LTR11_HOLD_TIME_3s", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465a199ab34fa29e36a379e57ba6c49e41f8", null ],
      [ "IFX_LTR11_HOLD_TIME_5s", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465a7b2f56951830dd0148195ce312707039", null ],
      [ "IFX_LTR11_HOLD_TIME_10s", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465a89ab6ca78a547f2b43f8b1aff5cd16b2", null ],
      [ "IFX_LTR11_HOLD_TIME_20s", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465af5be04828e405dfa52437c45d21b0cf5", null ],
      [ "IFX_LTR11_HOLD_TIME_45s", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465a43961ee7de15f787302ddb46d695b041", null ],
      [ "IFX_LTR11_HOLD_TIME_60s", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465a4603de4022269d631bf2980989195e88", null ],
      [ "IFX_LTR11_HOLD_TIME_90s", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465ac1e21086939d3f58c9ab4ddd89c05118", null ],
      [ "IFX_LTR11_HOLD_TIME_2min", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465a1afc395844b6036c477c9736235d3ab4", null ],
      [ "IFX_LTR11_HOLD_TIME_5min", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465af68fdb23fb165abf98e14a92d0a7deae", null ],
      [ "IFX_LTR11_HOLD_TIME_10min", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465a6f467846a3d76c99d878fb4737aa7441", null ],
      [ "IFX_LTR11_HOLD_TIME_15min", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465afbf46ab0004201ef0491a22474b19bd5", null ],
      [ "IFX_LTR11_HOLD_TIME_30min", "ifx_doppler_l_t_r11_2_types_8h.html#a6606e979c9c174082633fd1f07d6b465ac7105a32d5b0f1a1948642db11bae853", null ]
    ] ],
    [ "ifx_LTR11_Internal_Detector_Threshold_t", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554", [
      [ "IFX_LTR11_INTERNAL_DETECTOR_THRESHOLD_66", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554a55eb5e03b85ddaf01abfbcc4ad90b3e3", null ],
      [ "IFX_LTR11_INTERNAL_DETECTOR_THRESHOLD_80", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554a3a107ecf9ffbda1d0957f4a0f9e81f51", null ],
      [ "IFX_LTR11_INTERNAL_DETECTOR_THRESHOLD_90", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554a29a0ed906ec5eb67a176f1576bbfe532", null ],
      [ "IFX_LTR11_INTERNAL_DETECTOR_THRESHOLD_112", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554a74e6d121c650444cef336333ec9eed5e", null ],
      [ "IFX_LTR11_INTERNAL_DETECTOR_THRESHOLD_136", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554a93209a7cb52428756a9f0b09abb371c6", null ],
      [ "IFX_LTR11_INTERNAL_DETECTOR_THRESHOLD_192", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554a6976a1f6310834dba6bfb2865448672f", null ],
      [ "IFX_LTR11_INTERNAL_DETECTOR_THRESHOLD_248", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554a5b3f4d36f527f61fb75a34dca475f9d7", null ],
      [ "IFX_LTR11_INTERNAL_DETECTOR_THRESHOLD_320", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554a9ebad716d50ac27e2d9c387db726c5f9", null ],
      [ "IFX_LTR11_INTERNAL_DETECTOR_THRESHOLD_384", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554af4d5c7362cba89898191d6ee21c4e464", null ],
      [ "IFX_LTR11_INTERNAL_DETECTOR_THRESHOLD_480", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554a2710dc1e52f65db2e2443ab4c3a4d4e6", null ],
      [ "IFX_LTR11_INTERNAL_DETECTOR_THRESHOLD_640", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554a4f260aeb7c50f7cdc45e4f1f9df4ce71", null ],
      [ "IFX_LTR11_INTERNAL_DETECTOR_THRESHOLD_896", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554a82fbfd943497e7ba3ff4630ac916c094", null ],
      [ "IFX_LTR11_INTERNAL_DETECTOR_THRESHOLD_1344", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554a2c6a556acfc48cec250e037da1adacaa", null ],
      [ "IFX_LTR11_INTERNAL_DETECTOR_THRESHOLD_1920", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554aad10925c90c1241bb90d1a8b75096b46", null ],
      [ "IFX_LTR11_INTERNAL_DETECTOR_THRESHOLD_2560", "ifx_doppler_l_t_r11_2_types_8h.html#a0185b8e31ad75ce546f7dd960f8b7554a57328ea836c1aaa630b8b35de1a51cc1", null ]
    ] ],
    [ "ifx_LTR11_PRT_t", "ifx_doppler_l_t_r11_2_types_8h.html#a05f0a6e9ae4fb7b18f40051f94624000", [
      [ "IFX_LTR11_PRT_250us", "ifx_doppler_l_t_r11_2_types_8h.html#a05f0a6e9ae4fb7b18f40051f94624000a9061734ca921628365791c3e0955c6ed", null ],
      [ "IFX_LTR11_PRT_500us", "ifx_doppler_l_t_r11_2_types_8h.html#a05f0a6e9ae4fb7b18f40051f94624000a97d2f595a5a5d1c24822a14299954693", null ],
      [ "IFX_LTR11_PRT_1000us", "ifx_doppler_l_t_r11_2_types_8h.html#a05f0a6e9ae4fb7b18f40051f94624000a1a35dca6a6cfc0e14c21d733abd69d0f", null ],
      [ "IFX_LTR11_PRT_2000us", "ifx_doppler_l_t_r11_2_types_8h.html#a05f0a6e9ae4fb7b18f40051f94624000a939876c8c605df636cd3b9a58ac3670d", null ]
    ] ],
    [ "ifx_LTR11_PulseWidth_t", "ifx_doppler_l_t_r11_2_types_8h.html#a7e2a38901f69fdf3f7fde6a29bd954a1", [
      [ "IFX_LTR11_PULSE_WIDTH_5us", "ifx_doppler_l_t_r11_2_types_8h.html#a7e2a38901f69fdf3f7fde6a29bd954a1a7e4ab41f79ced645128274763ba301b8", null ],
      [ "IFX_LTR11_PULSE_WIDTH_10us", "ifx_doppler_l_t_r11_2_types_8h.html#a7e2a38901f69fdf3f7fde6a29bd954a1a5a7c563df8f7ca120cbcf320c49c7fb5", null ],
      [ "IFX_LTR11_PULSE_WIDTH_3us", "ifx_doppler_l_t_r11_2_types_8h.html#a7e2a38901f69fdf3f7fde6a29bd954a1a88d47d7aa519d32e4e39d7e443137519", null ],
      [ "IFX_LTR11_PULSE_WIDTH_4us", "ifx_doppler_l_t_r11_2_types_8h.html#a7e2a38901f69fdf3f7fde6a29bd954a1a8956866fdcdf0d22f9f57e198d793342", null ]
    ] ],
    [ "ifx_LTR11_rf_band_selection", "ifx_doppler_l_t_r11_2_types_8h.html#ab5e0e5ef028dbf2de160110858b37ca8", [
      [ "IFX_LTR11_RF_BAND_COMMON", "ifx_doppler_l_t_r11_2_types_8h.html#ab5e0e5ef028dbf2de160110858b37ca8a5733831766ba460877909ac3d489db4c", null ],
      [ "IFX_LTR11_RF_BAND_JAPAN", "ifx_doppler_l_t_r11_2_types_8h.html#ab5e0e5ef028dbf2de160110858b37ca8adffa3bf6fe5e52b59ee375ebb50420bc", null ]
    ] ],
    [ "ifx_LTR11_RxIFGain_t", "ifx_doppler_l_t_r11_2_types_8h.html#add19ee3a9be600cba84132f8628d65ab", [
      [ "IFX_LTR11_RX_IF_GAIN_10dB", "ifx_doppler_l_t_r11_2_types_8h.html#add19ee3a9be600cba84132f8628d65aba278723c81bdd883c2b078edaf8600177", null ],
      [ "IFX_LTR11_RX_IF_GAIN_15dB", "ifx_doppler_l_t_r11_2_types_8h.html#add19ee3a9be600cba84132f8628d65abaafa853c281c405c4fe94afa4d5ce466c", null ],
      [ "IFX_LTR11_RX_IF_GAIN_20dB", "ifx_doppler_l_t_r11_2_types_8h.html#add19ee3a9be600cba84132f8628d65aba0b5701f37a368c20ce52682a2cab4d13", null ],
      [ "IFX_LTR11_RX_IF_GAIN_25dB", "ifx_doppler_l_t_r11_2_types_8h.html#add19ee3a9be600cba84132f8628d65aba970b98f553a30c266bb49a5ebc2111ed", null ],
      [ "IFX_LTR11_RX_IF_GAIN_30dB", "ifx_doppler_l_t_r11_2_types_8h.html#add19ee3a9be600cba84132f8628d65aba71e46bc4796ee7ccad490caa15f6250c", null ],
      [ "IFX_LTR11_RX_IF_GAIN_35dB", "ifx_doppler_l_t_r11_2_types_8h.html#add19ee3a9be600cba84132f8628d65abaa85cbbbe58b6953247926b07b0d28684", null ],
      [ "IFX_LTR11_RX_IF_GAIN_40dB", "ifx_doppler_l_t_r11_2_types_8h.html#add19ee3a9be600cba84132f8628d65abac10ecd737ecb9e3d37bee267dd7eb351", null ],
      [ "IFX_LTR11_RX_IF_GAIN_45dB", "ifx_doppler_l_t_r11_2_types_8h.html#add19ee3a9be600cba84132f8628d65aba6fec517b559fc06ffeb0538257153a2c", null ],
      [ "IFX_LTR11_RX_IF_GAIN_50dB", "ifx_doppler_l_t_r11_2_types_8h.html#add19ee3a9be600cba84132f8628d65abab3e3cb65ccaaab433c32732b81599242", null ]
    ] ],
    [ "ifx_LTR11_TxPowerLevel_t", "ifx_doppler_l_t_r11_2_types_8h.html#a04b22d3c638637b8c59a5ada11067886", [
      [ "IFX_LTR11_TX_POWER_LEVEL_MINUS_34dBm", "ifx_doppler_l_t_r11_2_types_8h.html#a04b22d3c638637b8c59a5ada11067886af3a08e4561cae4e9cc4cd3f4afadb32e", null ],
      [ "IFX_LTR11_TX_POWER_LEVEL_MINUS_31_5dBm", "ifx_doppler_l_t_r11_2_types_8h.html#a04b22d3c638637b8c59a5ada11067886a8e288fc8bae506c31c6608fee7c7333e", null ],
      [ "IFX_LTR11_TX_POWER_LEVEL_MINUS_25dBm", "ifx_doppler_l_t_r11_2_types_8h.html#a04b22d3c638637b8c59a5ada11067886a0e498f1850737b289b0647702a96f7ca", null ],
      [ "IFX_LTR11_TX_POWER_LEVEL_MINUS_18dBm", "ifx_doppler_l_t_r11_2_types_8h.html#a04b22d3c638637b8c59a5ada11067886a4a3427044333760d32872ab3d365fc24", null ],
      [ "IFX_LTR11_TX_POWER_LEVEL_MINUS_11dBm", "ifx_doppler_l_t_r11_2_types_8h.html#a04b22d3c638637b8c59a5ada11067886a1f351ec18838de476600b41f430e6672", null ],
      [ "IFX_LTR11_TX_POWER_LEVEL_MINUS_5dBm", "ifx_doppler_l_t_r11_2_types_8h.html#a04b22d3c638637b8c59a5ada11067886a7b47d267bd96d42a91807b547b5d79ae", null ],
      [ "IFX_LTR11_TX_POWER_LEVEL_0dBm", "ifx_doppler_l_t_r11_2_types_8h.html#a04b22d3c638637b8c59a5ada11067886ace8521c272c3c053bfbe33001ae9b8c5", null ],
      [ "IFX_LTR11_TX_POWER_LEVEL_4_5dBm", "ifx_doppler_l_t_r11_2_types_8h.html#a04b22d3c638637b8c59a5ada11067886a0e78a3f4b1351ca8dd4d3551189ee619", null ]
    ] ]
];