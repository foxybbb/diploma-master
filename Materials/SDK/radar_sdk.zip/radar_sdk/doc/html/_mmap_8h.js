var _mmap_8h =
[
    [ "ifx_MMAP_t", "_mmap_8h.html#a2dd1cc65cce0f1c0cdcba030a26a9e5b", null ],
    [ "ifx_mmap_const_data", "_mmap_8h.html#ae1c95c431112744c9516a0eebc384488", null ],
    [ "ifx_mmap_create", "_mmap_8h.html#a0d11f6a00c6bd7ed4615232e9e040c20", null ],
    [ "ifx_mmap_destroy", "_mmap_8h.html#a55399f6853d28d76014445479ed6edf0", null ]
];