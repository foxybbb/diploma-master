var _motion_angle_8h =
[
    [ "ifx_MotionAngle_t", "group__gr__motionangle.html#gaae62aaee410a76bf52b6bacde566b6aa", null ],
    [ "ifx_MotionAngle_Mode_t", "group__gr__motionangle.html#ga1539b66d5c8814d6d9dd5c0e5d00b7a5", [
      [ "IFX_MOTIONANGLE_430MHZ_32SPC", "group__gr__motionangle.html#gga1539b66d5c8814d6d9dd5c0e5d00b7a5a1f3c19edfc5328ec376f4eae7c124fc6", null ],
      [ "IFX_MOTIONANGLE_430MHZ_32SPC_50FPS_8CPF", "group__gr__motionangle.html#gga1539b66d5c8814d6d9dd5c0e5d00b7a5abd473c3eb81446fbfc381a863b5962f3", null ],
      [ "IFX_MOTIONANGLE_430MHZ_32SPC_50FPS_16CPF", "group__gr__motionangle.html#gga1539b66d5c8814d6d9dd5c0e5d00b7a5ad0f8161d25a9e7e260e8c81a56e34319", null ],
      [ "IFX_MOTIONANGLE_430MHZ_32SPC_50FPS_32CPF", "group__gr__motionangle.html#gga1539b66d5c8814d6d9dd5c0e5d00b7a5a51090a4086bd1d7398a04dbf49eb9a4c", null ],
      [ "IFX_MOTIONANGLE_430MHZ_32SPC_50FPS_64CPF", "group__gr__motionangle.html#gga1539b66d5c8814d6d9dd5c0e5d00b7a5a63e56a1f1887d8d518a0d65452525c23", null ]
    ] ],
    [ "ifx_motionangle_create", "group__gr__motionangle.html#ga3cf6d4824870c8a47ee1c849bc24fdd7", null ],
    [ "ifx_motionangle_create_from_mode", "group__gr__motionangle.html#gac64504fc34b319583a6a0320b08d83ff", null ],
    [ "ifx_motionangle_destroy", "group__gr__motionangle.html#ga3f984c6e172cda8be7f824dc85716dcb", null ],
    [ "ifx_motionangle_get_maxrange", "group__gr__motionangle.html#gaa0f606da34819708385d8b28f38574d9", null ],
    [ "ifx_motionangle_get_sensitivity", "group__gr__motionangle.html#ga262b64f1c27c9ece1a5362302d9cb220", null ],
    [ "ifx_motionangle_run", "group__gr__motionangle.html#ga437275bcc63f7c73e81c0278337a8674", null ],
    [ "ifx_motionangle_set_maxrange", "group__gr__motionangle.html#ga81f8b0e053e2623440d2a48f4814aa0b", null ],
    [ "ifx_motionangle_set_sensitivity", "group__gr__motionangle.html#gab0d934a15f8c23ebf15c9622f2c257f0", null ]
];