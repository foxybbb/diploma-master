var _recording_8h =
[
    [ "ifx_Recording_t", "group__gr__recording.html#ga554404a3d90fec773d2697ca13bc001d", null ],
    [ "ifx_Recording_Mode_t", "group__gr__recording.html#ga43c8c84248e594acc6c1ccd709eb52ee", [
      [ "IFX_RECORDING_READ_MODE", "group__gr__recording.html#gga43c8c84248e594acc6c1ccd709eb52eea77233b88d26a3ed62fad9495c0f7ec34", null ],
      [ "IFX_RECORDING_WRITE_MODE", "group__gr__recording.html#gga43c8c84248e594acc6c1ccd709eb52eea0f0832769b2fd6e326f063c5b9d1c9e7", null ],
      [ "IFX_RECORDING_READ_WRITE_MODE", "group__gr__recording.html#gga43c8c84248e594acc6c1ccd709eb52eea8e18332fdbd22795b129e0a27998579f", null ]
    ] ],
    [ "ifx_Recording_Type_t", "group__gr__recording.html#gaafad35553893390971ea90cae864bd41", [
      [ "IFX_RECORDING_AVIAN", "group__gr__recording.html#ggaafad35553893390971ea90cae864bd41a0a3167a0778dc39a90f89197a603269e", null ],
      [ "IFX_RECORDING_UNKNOWN", "group__gr__recording.html#ggaafad35553893390971ea90cae864bd41a5787a26636fd395fa48b99c7c82d2ceb", null ]
    ] ],
    [ "ifx_recording_create", "group__gr__recording.html#ga2a29181d3216226929faa83028c650b3", null ],
    [ "ifx_recording_destroy", "group__gr__recording.html#ga9d7d77565a077098b9768fc14fbf2232", null ],
    [ "ifx_recording_get_format_version", "group__gr__recording.html#ga6a9ef5c4eb2ca6aa5881b4397cc2d1e6", null ],
    [ "ifx_recording_list", "group__gr__recording.html#ga49e9280bd295c0a29c56fcaa754b085a", null ]
];