var group__gr__mem =
[
    [ "ifx_mem_aligned_alloc", "group__gr__mem.html#ga7138cea108adc0bd15fb7555be8db1c5", null ],
    [ "ifx_mem_aligned_free", "group__gr__mem.html#ga84c554d9f5445bb2f2dc8f744b7e1861", null ],
    [ "ifx_mem_alloc", "group__gr__mem.html#ga30c6cee9eaeacbbc232c9ea2a12ad940", null ],
    [ "ifx_mem_calloc", "group__gr__mem.html#ga62ce7fae30ffbb781cdee87b05cf3eb2", null ],
    [ "ifx_mem_free", "group__gr__mem.html#gaee171354394f65ae21092c4a5cb64e64", null ]
];