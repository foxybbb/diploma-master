var group__gr__deviceconfig =
[
    [ "ifx_devconf_count_rx_antennas", "group__gr__deviceconfig.html#ga34dff39dd92cfc04df275440d3128378", null ],
    [ "ifx_devconf_get_bandwidth", "group__gr__deviceconfig.html#gaefdf41cb571736dce92028ab148810a0", null ],
    [ "ifx_devconf_get_center_frequency", "group__gr__deviceconfig.html#ga1d8feab2cba541733731ee1bd2ab1fee", null ],
    [ "ifx_devconf_get_chirp_repetition_time", "group__gr__deviceconfig.html#ga8914b92900011e2926b08bcf362d16a2", null ],
    [ "ifx_devconf_get_chirp_time", "group__gr__deviceconfig.html#ga64a9771b4b3e232d5b4a290bb426c7f1", null ]
];