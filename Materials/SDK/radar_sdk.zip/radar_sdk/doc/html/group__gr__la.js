var group__gr__la =
[
    [ "ifx_la_cholesky_c", "group__gr__la.html#ga695b070c157d8d15d12cd1c54bd063f0", null ],
    [ "ifx_la_cholesky_r", "group__gr__la.html#ga8fe760903f9ca718a51a498a9527db2d", null ],
    [ "ifx_la_determinant_c", "group__gr__la.html#gaf21fde0f6297d41493aa7f348f123b38", null ],
    [ "ifx_la_determinant_r", "group__gr__la.html#gadbb3fcc05243f098e93b8d0eaa3e163a", null ],
    [ "ifx_la_invert_c", "group__gr__la.html#gaadfaac84dbfb5e2aa87406e1ee37d451", null ],
    [ "ifx_la_invert_r", "group__gr__la.html#ga45255218e915551cff91318b95edc86b", null ]
];