var _range_angle_image_8h =
[
    [ "ifx_RAI_Config_t", "structifx___r_a_i___config__t.html", "structifx___r_a_i___config__t" ],
    [ "ifx_RAI_t", "_range_angle_image_8h.html#a7172d7dd68d906f8ea0d422444857159", null ],
    [ "ifx_rai_create", "group__gr__rai.html#ga5f0fa3ed09b062b65c1fb566da46cadf", null ],
    [ "ifx_rai_destroy", "group__gr__rai.html#ga35d5fe585bf98abb84cb7cb2be2d6cbd", null ],
    [ "ifx_rai_get_range_doppler", "group__gr__rai.html#ga173d6256b39a00108220d943ad8f2c99", null ],
    [ "ifx_rai_get_rx_spectrum", "group__gr__rai.html#gac8cc56e2f0625d42d0123d9b45f3bd02", null ],
    [ "ifx_rai_get_snr", "group__gr__rai.html#ga424b199efadea6c42e4416b2defde43a", null ],
    [ "ifx_rai_run_r", "group__gr__rai.html#ga1bce408acbef2035c33b743c457c31e6", null ]
];