var _spectrum_axis_8h =
[
    [ "ifx_spectrum_axis_calc_beat_freq_axis", "group__gr__sa.html#ga76e45d282ef44a07304e23199f33c143", null ],
    [ "ifx_spectrum_axis_calc_beat_freq_per_bin", "group__gr__sa.html#ga9fadb811278a16f7d91ed1d0f4162150", null ],
    [ "ifx_spectrum_axis_calc_dist_per_bin", "group__gr__sa.html#ga48a53d8ad17561e4c5f20d1edb2b05b1", null ],
    [ "ifx_spectrum_axis_calc_range_axis", "group__gr__sa.html#gae1625c24c092b186a8eeb533750a4cb6", null ],
    [ "ifx_spectrum_axis_calc_sampling_freq_axis", "group__gr__sa.html#gacf367343a33ed486df965c7429f3d154", null ],
    [ "ifx_spectrum_axis_calc_speed_axis", "group__gr__sa.html#ga759ea7d56558ab987fc8caec2ba2c00b", null ],
    [ "ifx_spectrum_axis_calc_speed_per_bin", "group__gr__sa.html#ga1472c035c4535e16d777694caf52e0dd", null ]
];