var group__gr__sdk__version =
[
    [ "ifx_sdk_get_version_hash", "group__gr__sdk__version.html#gaab0387ee8f35e77b0b41de89dfdf8e5f", null ],
    [ "ifx_sdk_get_version_string", "group__gr__sdk__version.html#gaf2a1d0548fc50fa20a4368ccca478693", null ],
    [ "ifx_sdk_get_version_string_full", "group__gr__sdk__version.html#ga4f34bb656b5db76437e3ec5c7de7f337", null ]
];