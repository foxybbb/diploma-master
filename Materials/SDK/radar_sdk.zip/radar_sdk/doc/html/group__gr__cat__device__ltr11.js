var group__gr__cat__device__ltr11 =
[
    [ "Device LTR11 (60GHz)", "group__gr__device__ltr11__control.html", "group__gr__device__ltr11__control" ]
];