var _range_doppler_map_8h =
[
    [ "ifx_RDM_Config_t", "structifx___r_d_m___config__t.html", "structifx___r_d_m___config__t" ],
    [ "ifx_RDM_t", "_range_doppler_map_8h.html#aa637a73a953ebd72004f6a3b5672e391", null ],
    [ "ifx_rdm_create", "group__gr__rdm.html#gaeed818c766e0f862cd9aca5561dde096", null ],
    [ "ifx_rdm_destroy", "group__gr__rdm.html#gaa9157f66509004fb3e9c34001f2a47b4", null ],
    [ "ifx_rdm_get_output_scale_type", "group__gr__rdm.html#ga9210a99948badd9e4649bba1468bf07d", null ],
    [ "ifx_rdm_get_threshold", "group__gr__rdm.html#ga7bf8ec9c861ac1c23d8057a27a0072bb", null ],
    [ "ifx_rdm_run_c", "group__gr__rdm.html#gaa2114454e255014caa3c5f8b487c4b0d", null ],
    [ "ifx_rdm_run_cr", "group__gr__rdm.html#ga5e7c6adc419996dc42e107770e07e72b", null ],
    [ "ifx_rdm_run_r", "group__gr__rdm.html#ga9d73602bb619c8a90a93310467771f59", null ],
    [ "ifx_rdm_run_rc", "group__gr__rdm.html#gaadee9d861f0f066da881b933620b8ba1", null ],
    [ "ifx_rdm_set_doppler_window", "group__gr__rdm.html#ga463215e289449a42ff60ad35a793a45f", null ],
    [ "ifx_rdm_set_output_scale_type", "group__gr__rdm.html#ga96b4775751e2598d8d96ac37bc49674f", null ],
    [ "ifx_rdm_set_range_window", "group__gr__rdm.html#ga4f0081d894459ed16ced68facc0b716f", null ],
    [ "ifx_rdm_set_threshold", "group__gr__rdm.html#gaaf453cfd88621f50679a584efa03f9ca", null ]
];