var _metrics_8h =
[
    [ "ifx_avian_metrics_from_config", "group__gr__avian__metrics.html#gaaf92c814b1dace9ce0b08e3353606dba", null ],
    [ "ifx_avian_metrics_get_defaults", "group__gr__avian__metrics.html#gae10b71ae88a8ea7be81583b137c66eb0", null ],
    [ "ifx_avian_metrics_get_limits", "group__gr__avian__metrics.html#gac842a20890f0748eec667675a1b32782", null ],
    [ "ifx_avian_metrics_to_config", "group__gr__avian__metrics.html#gad3b9883936f56dd513cbec23eb634333", null ]
];