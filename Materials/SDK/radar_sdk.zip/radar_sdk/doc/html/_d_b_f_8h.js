var _d_b_f_8h =
[
    [ "ifx_DBF_Config_t", "structifx___d_b_f___config__t.html", "structifx___d_b_f___config__t" ],
    [ "ifx_DBF_t", "_d_b_f_8h.html#a6a8a6c280b631019453ac328f49b84a0", null ],
    [ "ifx_dbf_create", "group__gr__dbf.html#ga74bad7a12a8c0717176a5df9b6b6ce93", null ],
    [ "ifx_dbf_destroy", "group__gr__dbf.html#gad2e28e5b4f772a7281fc365d6b066ded", null ],
    [ "ifx_dbf_get_beam_count", "group__gr__dbf.html#gafdf942647acb960e898b2a9bfeb51c7e", null ],
    [ "ifx_dbf_run_c", "group__gr__dbf.html#ga208ce9ac0432a84370e1822577f5ecaa", null ]
];