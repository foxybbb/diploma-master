var _mem_8h =
[
    [ "IFX_ALIGN", "_mem_8h.html#a17ff27e892495f13f1912b8882d569b5", null ],
    [ "IFX_IS_ALIGNED", "_mem_8h.html#a3a67fdfe48ce211048720bd46e4d7d9c", null ],
    [ "IFX_MEMORY_ALIGNMENT", "_mem_8h.html#a4ad4e3112d3e58517cde5cf734d7a6d1", null ],
    [ "ifx_mem_aligned_alloc", "group__gr__mem.html#ga7138cea108adc0bd15fb7555be8db1c5", null ],
    [ "ifx_mem_aligned_free", "group__gr__mem.html#ga84c554d9f5445bb2f2dc8f744b7e1861", null ],
    [ "ifx_mem_alloc", "group__gr__mem.html#ga30c6cee9eaeacbbc232c9ea2a12ad940", null ],
    [ "ifx_mem_calloc", "group__gr__mem.html#ga62ce7fae30ffbb781cdee87b05cf3eb2", null ],
    [ "ifx_mem_free", "group__gr__mem.html#gaee171354394f65ae21092c4a5cb64e64", null ]
];