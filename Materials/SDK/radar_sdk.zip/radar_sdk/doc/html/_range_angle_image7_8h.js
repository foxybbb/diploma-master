var _range_angle_image7_8h =
[
    [ "ifx_RAI_Opt_Config_s", "structifx___r_a_i___opt___config__s.html", "structifx___r_a_i___opt___config__s" ],
    [ "ifx_RAI_Opt_Config_t", "_range_angle_image7_8h.html#aec3811bd571f964de05bacf50b9be587", null ],
    [ "ifx_RAI_Opt_t", "_range_angle_image7_8h.html#a4eaeda7286bc7aa9672f6e8d76fd7760", null ],
    [ "ifx_rai7_create", "_range_angle_image7_8h.html#ab32fe46582ae618374217906ee4e152b", null ],
    [ "ifx_rai7_destroy", "_range_angle_image7_8h.html#a6a433f0fe09d6b66de1c94407ab247cf", null ],
    [ "ifx_rai7_get_rx_spectrum", "_range_angle_image7_8h.html#a4ead1344080b661b7d8d1bc2e8a26343", null ],
    [ "ifx_rai7_get_snr", "_range_angle_image7_8h.html#a893abed0b2519181a81f290ffa1c16c5", null ],
    [ "ifx_rai7_run_r", "_range_angle_image7_8h.html#af3b1946f35c9edfbd53bed474a247c56", null ]
];