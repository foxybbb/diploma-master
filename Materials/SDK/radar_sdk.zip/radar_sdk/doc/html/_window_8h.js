var _window_8h =
[
    [ "ifx_Window_Config_t", "structifx___window___config__t.html", "structifx___window___config__t" ],
    [ "ifx_Window_Type_t", "_window_8h.html#a4104d5848615f2111db1f3eaca27fd68", [
      [ "IFX_WINDOW_HAMM", "_window_8h.html#a4104d5848615f2111db1f3eaca27fd68aeddcec0e51b4cca13578310b9b29585a", null ],
      [ "IFX_WINDOW_HANN", "_window_8h.html#a4104d5848615f2111db1f3eaca27fd68a807da2e6259dea134a529bda9ec1d1aa", null ],
      [ "IFX_WINDOW_BLACKMANHARRIS", "_window_8h.html#a4104d5848615f2111db1f3eaca27fd68a6fce6681a0ce83c2116d5dad5a37ca09", null ],
      [ "IFX_WINDOW_CHEBYSHEV", "_window_8h.html#a4104d5848615f2111db1f3eaca27fd68a2f925eab92b34769ed8b0ca6e731a88d", null ],
      [ "IFX_WINDOW_BLACKMAN", "_window_8h.html#a4104d5848615f2111db1f3eaca27fd68a7491731c8394608000a409b20f85b9e8", null ]
    ] ],
    [ "ifx_window_init", "group__gr__window.html#gaab5b1dbddc3a3cf9fef19f2b51adc0b2", null ]
];