var _target_8h =
[
    [ "IFX_OFFSET_OF", "group__gr__target.html#ga097de30ea619f16429a648cd08c02c88", null ],
    [ "IFX_TARGET_AZIMUTH_ANGLE", "group__gr__target.html#ga427051467de19825b5b15e3582825839", null ],
    [ "IFX_TARGET_AZIMUTH_ANGLE_COL_OFFSET", "group__gr__target.html#ga22e406c0d55a213c8d2b4c25fc386a9e", null ],
    [ "IFX_TARGET_COL_OF", "group__gr__target.html#gaeef89e37529ed79e75737de1a3dc4cc8", null ],
    [ "IFX_TARGET_COORD", "group__gr__target.html#gac164f7048e7c3910432bf0344693a941", null ],
    [ "IFX_TARGET_COORDS_COL_OFFSET", "group__gr__target.html#gaa5f6554bbc7c7514385a89de6817c73d", null ],
    [ "IFX_TARGET_COORDS_LEN", "group__gr__target.html#ga11178766b6c6c1e536018e7244b46bba", null ],
    [ "IFX_TARGET_MATRIX_CREATE", "group__gr__target.html#gab468f979626820a3285e96077105fb4d", null ],
    [ "IFX_TARGET_RANGE", "group__gr__target.html#gab04f4e94298abb19dbc86de29d3befa8", null ],
    [ "IFX_TARGET_RANGE_COL_OFFSET", "group__gr__target.html#gad63e50d0970763b23ec683ba2cbefb3f", null ],
    [ "IFX_TARGET_SPEED", "group__gr__target.html#gaa872682845055b82f72e6866f5b92657", null ],
    [ "IFX_TARGET_SPEED_COL_OFFSET", "group__gr__target.html#gaf49077551711e57fd164b73c1855b0c1", null ]
];