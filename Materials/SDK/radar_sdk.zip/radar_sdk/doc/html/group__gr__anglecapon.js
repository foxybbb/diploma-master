var group__gr__anglecapon =
[
    [ "ifx_anglecapon_create", "group__gr__anglecapon.html#ga532ac2aea4d0a8730a9de60b7b169535", null ],
    [ "ifx_anglecapon_destroy", "group__gr__anglecapon.html#gac5bcfcc25807d4eba5b5ae5956668601", null ],
    [ "ifx_anglecapon_run", "group__gr__anglecapon.html#ga10698f765f650cb0f655f14d9ddf164b", null ]
];