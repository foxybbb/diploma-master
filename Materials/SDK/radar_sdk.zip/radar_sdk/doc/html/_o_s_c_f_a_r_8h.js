var _o_s_c_f_a_r_8h =
[
    [ "ifx_OSCFAR_Config_t", "structifx___o_s_c_f_a_r___config__t.html", "structifx___o_s_c_f_a_r___config__t" ],
    [ "ifx_OSCFAR_t", "_o_s_c_f_a_r_8h.html#a03e33c7d83f0a4cba647d73432a1b158", null ],
    [ "ifx_oscfar_create", "group__gr__oscfar.html#ga3dbef67ff926d9bcaa8346121f7ac152", null ],
    [ "ifx_oscfar_destroy", "group__gr__oscfar.html#gaa5b8457950066d770927350ce80068fd", null ],
    [ "ifx_oscfar_run", "group__gr__oscfar.html#gae560233b7ef228b7ac5aeac22a553955", null ]
];