var _advanced_motion_sensing_8h =
[
    [ "ifx_Advanced_Motion_Sensing_t", "group__gr__cat___motion_sensing.html#ga4ba309a9ef129a33e28a93ecfcfac210", null ],
    [ "ifx_Target_Detection_t", "group__gr__cat___motion_sensing.html#gaea1d7d9131435752f7c92af8c12de1d9", [
      [ "NO_TARGET_DETECTED", "group__gr__cat___motion_sensing.html#ggaea1d7d9131435752f7c92af8c12de1d9a0593bacb16c40e3f4354b74623b8e79b", null ],
      [ "TARGET_MOTION_DETECTED", "group__gr__cat___motion_sensing.html#ggaea1d7d9131435752f7c92af8c12de1d9aa175ca111e94169d6da657a95a870d0f", null ],
      [ "POTENTIAL_TARGET_DETECTED", "group__gr__cat___motion_sensing.html#ggaea1d7d9131435752f7c92af8c12de1d9a16d13cce81f1d81e4c8465b2b5ca6c35", null ]
    ] ],
    [ "ifx_advanced_motion_sensing_create", "group__gr__cat___motion_sensing.html#ga2c0ff4d5ebd8d2e917857c9a2f873850", null ],
    [ "ifx_advanced_motion_sensing_destroy", "group__gr__cat___motion_sensing.html#ga39651cc17a16b737caa1fe0be8bb5cf4", null ],
    [ "ifx_advanced_motion_sensing_get_config_limits", "group__gr__cat___motion_sensing.html#ga642a0f0d21bb13609c070113fe25fbfc", null ],
    [ "ifx_advanced_motion_sensing_run", "group__gr__cat___motion_sensing.html#gaa6dc7227b08aabb5ff450cccbb06851c", null ]
];