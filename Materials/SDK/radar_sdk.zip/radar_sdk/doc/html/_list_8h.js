var _list_8h =
[
    [ "ifx_List_t", "group__gr__list.html#ga1901843bffc0b7777925c08a9c250841", null ],
    [ "ifx_list_create", "group__gr__list.html#gaf1f859a20f0eefe69e778bd04756970b", null ],
    [ "ifx_list_destroy", "group__gr__list.html#ga1ce8dcdef13a3869e20b90658f90914d", null ],
    [ "ifx_list_get", "group__gr__list.html#gad9900a449c681b4a30038104f01ad00e", null ],
    [ "ifx_list_push_back", "group__gr__list.html#ga1a647776a5cbea09e034b789c787c809", null ],
    [ "ifx_list_size", "group__gr__list.html#ga8a2fbf5d61b337c30387141c3c023eaf", null ]
];