var _uuid_8h =
[
    [ "ifx_uuid_from_string", "_uuid_8h.html#ae28d5ddf4875d3543b7f0a08458057a3", null ],
    [ "ifx_uuid_to_string", "_uuid_8h.html#a2dfc4ed6dadf1ed5993382013c2d38f5", null ]
];