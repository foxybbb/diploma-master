## nlohmann/json

* [on github](https://github.com/nlohmann/json)
* License: MIT
