var searchData=
[
  ['get_5fphase_5foffset_131',['get_phase_offset',['../wrapper_8h.html#a49fb818396d5748a426dd60ed91b26cc',1,'wrapper.h']]],
  ['guard_5fband_132',['guard_band',['../structifx___o_s_c_f_a_r___config__t.html#ab85fc99590eba4d6c67b890e213c11a1',1,'ifx_OSCFAR_Config_t']]]
];
