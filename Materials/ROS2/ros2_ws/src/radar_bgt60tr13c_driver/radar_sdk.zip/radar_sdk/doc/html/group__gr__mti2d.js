var group__gr__mti2d =
[
    [ "ifx_2dmti_create_c", "group__gr__mti2d.html#gad5b45e3c108faca784a40422faea6b6a", null ],
    [ "ifx_2dmti_create_r", "group__gr__mti2d.html#ga9076d446ca17324e47df6b1281c33293", null ],
    [ "ifx_2dmti_destroy_c", "group__gr__mti2d.html#gad20e1b11a403b68ce288d3a7e939ca63", null ],
    [ "ifx_2dmti_destroy_r", "group__gr__mti2d.html#gacd03fb6dc9a6b67d7fa86bd08f7ef08d", null ],
    [ "ifx_2dmti_get_filter_coeff_c", "group__gr__mti2d.html#gaf46b7b3a03b7af007b1e371b8345dcea", null ],
    [ "ifx_2dmti_get_filter_coeff_r", "group__gr__mti2d.html#ga4759359ec641a4c9f4ca44b43d9fff17", null ],
    [ "ifx_2dmti_run_c", "group__gr__mti2d.html#gabf46b445318df26fc674dd1db06c061e", null ],
    [ "ifx_2dmti_run_r", "group__gr__mti2d.html#ga9f513f195cd3e4f797999deb572fd5bf", null ],
    [ "ifx_2dmti_set_filter_coeff_c", "group__gr__mti2d.html#ga807f458028dbd104be43ef3fc6424033", null ],
    [ "ifx_2dmti_set_filter_coeff_r", "group__gr__mti2d.html#gac1221ed065f87582c2e4b61ee2d8c8bc", null ]
];