var searchData=
[
  ['sin_2932',['SIN',['../_defines_8h.html#ac80ce9955a1af2ab7aa3a67251ec9f5c',1,'Defines.h']]],
  ['sincos_2933',['SINCOS',['../_defines_8h.html#a8fac50eb7e5fe3c7cf36aa9ff03a5ca4',1,'Defines.h']]],
  ['sind_2934',['SIND',['../_defines_8h.html#a08b6f3cc646f95d4da1006b2a5365cae',1,'Defines.h']]],
  ['sinh_2935',['SINH',['../_defines_8h.html#a84b9b00b5c0df2cdb4c50e85ca4c2dbc',1,'Defines.h']]],
  ['sqrt_2936',['SQRT',['../_defines_8h.html#a095e93222540fb38e433670cf08b5a46',1,'Defines.h']]]
];
