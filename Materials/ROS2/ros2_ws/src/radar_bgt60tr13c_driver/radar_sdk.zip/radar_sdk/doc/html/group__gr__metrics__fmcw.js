var group__gr__metrics__fmcw =
[
    [ "ifx_Fmcw_Metrics_t", "structifx___fmcw___metrics__t.html", [
      [ "center_frequency_Hz", "structifx___fmcw___metrics__t.html#a175b44911577c99867f3c893e6c00ea1", null ],
      [ "max_range_m", "structifx___fmcw___metrics__t.html#a8d6255becbd1e46a38a91afad499eb68", null ],
      [ "max_speed_m_s", "structifx___fmcw___metrics__t.html#a6c71f028fd6dce87f545abf1ffaa0131", null ],
      [ "range_resolution_m", "structifx___fmcw___metrics__t.html#a94f47ce409bc111cd34434f598d5fa08", null ],
      [ "speed_resolution_m_s", "structifx___fmcw___metrics__t.html#aaa05fccc08f293debd40a276a241a789", null ]
    ] ],
    [ "ifx_fmcw_metrics_from_sequence", "group__gr__metrics__fmcw.html#ga4e780cef4682be4cd556dd9308b3409e", null ],
    [ "ifx_fmcw_sequence_from_metrics", "group__gr__metrics__fmcw.html#ga7ab84055242dc5cb38042b2fc204f5a4", null ]
];