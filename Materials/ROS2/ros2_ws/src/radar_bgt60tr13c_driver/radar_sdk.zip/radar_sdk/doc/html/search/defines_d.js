var searchData=
[
  ['vf32x4_2942',['vf32x4',['../_s_i_m_d_8h.html#ac15c64239c447dfd255e30b7e82b0ea6',1,'SIMD.h']]],
  ['vf32x4_5fadd_2943',['vf32x4_add',['../_s_i_m_d_8h.html#acc31f30758aa1c143dbfabfe3b846551',1,'SIMD.h']]],
  ['vf32x4_5fextract1_2944',['vf32x4_extract1',['../_s_i_m_d_8h.html#ace5ddf86c23947931e720bb9aef70a9e',1,'SIMD.h']]],
  ['vf32x4_5fload_2945',['vf32x4_load',['../_s_i_m_d_8h.html#a738e30bc2b7eb697483f8575ae618f3c',1,'SIMD.h']]],
  ['vf32x4_5fload1_2946',['vf32x4_load1',['../_s_i_m_d_8h.html#adfc0755c40023439b0f3b2b758ed9eee',1,'SIMD.h']]],
  ['vf32x4_5fmax_2947',['vf32x4_max',['../_s_i_m_d_8h.html#a1fdc79bcf42fa54a72b7e518653d88aa',1,'SIMD.h']]],
  ['vf32x4_5fmla_2948',['vf32x4_mla',['../_s_i_m_d_8h.html#a1e134e068dca329647d8a579d42991b8',1,'SIMD.h']]],
  ['vf32x4_5fmls_2949',['vf32x4_mls',['../_s_i_m_d_8h.html#aa8448bdf23b25ad8253bb22e0083bfe0',1,'SIMD.h']]],
  ['vf32x4_5fmul_2950',['vf32x4_mul',['../_s_i_m_d_8h.html#aa71207c8bd0437d5ed24876d181eb5c9',1,'SIMD.h']]],
  ['vf32x4_5frsqrt_2951',['vf32x4_rsqrt',['../_s_i_m_d_8h.html#a5e4cc115745a73f0f7feb3c095555e34',1,'SIMD.h']]],
  ['vf32x4_5fset_2952',['vf32x4_set',['../_s_i_m_d_8h.html#aff14fb96cbd6279de82d7408e06dadf8',1,'SIMD.h']]],
  ['vf32x4_5fset1_2953',['vf32x4_set1',['../_s_i_m_d_8h.html#a9ee8468b96aa79dc6fb899e8c483f57b',1,'SIMD.h']]],
  ['vf32x4_5fsetzero_2954',['vf32x4_setzero',['../_s_i_m_d_8h.html#ad1023c8635e9bc62ee51751c300ce3c7',1,'SIMD.h']]],
  ['vf32x4_5fstor_2955',['vf32x4_stor',['../_s_i_m_d_8h.html#af97d6373363147b565b702132d5a81ec',1,'SIMD.h']]],
  ['vf32x4_5fsub_2956',['vf32x4_sub',['../_s_i_m_d_8h.html#aeb982e3a37e9a3d25cd2ed7939a5f6cc',1,'SIMD.h']]]
];
