var group__gr__cat__device__mimose =
[
    [ "Device Mimose Control (24GHz)", "group__gr__device__mimose__control.html", "group__gr__device__mimose__control" ],
    [ "Mimose Types", "group__gr__device__mimose__types.html", "group__gr__device__mimose__types" ]
];