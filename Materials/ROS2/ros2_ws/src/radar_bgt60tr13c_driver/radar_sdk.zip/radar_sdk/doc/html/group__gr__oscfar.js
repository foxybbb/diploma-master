var group__gr__oscfar =
[
    [ "ifx_oscfar_create", "group__gr__oscfar.html#ga3dbef67ff926d9bcaa8346121f7ac152", null ],
    [ "ifx_oscfar_destroy", "group__gr__oscfar.html#gaa5b8457950066d770927350ce80068fd", null ],
    [ "ifx_oscfar_run", "group__gr__oscfar.html#gae560233b7ef228b7ac5aeac22a553955", null ]
];