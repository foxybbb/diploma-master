var group__gr__ppfft =
[
    [ "ifx_ppfft_calc_freq_axis", "group__gr__ppfft.html#ga61b4ce3b655e8da6319ccf97b388e1fd", null ],
    [ "ifx_ppfft_create", "group__gr__ppfft.html#ga7d96ee4517b29499b8700835e247b489", null ],
    [ "ifx_ppfft_destroy", "group__gr__ppfft.html#ga47760c046cd6586623ab4cdeb245282b", null ],
    [ "ifx_ppfft_get_fft_size", "group__gr__ppfft.html#gaf3cf3e719e8b28a1b0e5854e8feadc90", null ],
    [ "ifx_ppfft_get_fft_type", "group__gr__ppfft.html#ga04c49400cf145f75fefb075429ece2b4", null ],
    [ "ifx_ppfft_get_mean_removal_flag", "group__gr__ppfft.html#gace7c1afedbdee9a43ba57718128032b3", null ],
    [ "ifx_ppfft_get_window", "group__gr__ppfft.html#ga0688ba7b5af83ed53523bf1fd60f8c90", null ],
    [ "ifx_ppfft_get_window_attenuation", "group__gr__ppfft.html#gab99760e251ae84b7b5665ac55ea95b1a", null ],
    [ "ifx_ppfft_get_window_config", "group__gr__ppfft.html#ga4fc74a3220f97cdb8b0ace6436da694f", null ],
    [ "ifx_ppfft_get_window_size", "group__gr__ppfft.html#ga55e8f69690961a74f0f618c3b6799c0c", null ],
    [ "ifx_ppfft_get_window_type", "group__gr__ppfft.html#gadbebb6acf31177db714c62d196a7a1e5", null ],
    [ "ifx_ppfft_run_c", "group__gr__ppfft.html#ga38b2271c3d9529b22c65647fcd613038", null ],
    [ "ifx_ppfft_run_rc", "group__gr__ppfft.html#ga4ae4075b990254f8bbe5396aa277b253", null ],
    [ "ifx_ppfft_set_mean_removal_flag", "group__gr__ppfft.html#gab9ee6c87db95a13f236c4b7c41e95490", null ],
    [ "ifx_ppfft_set_window", "group__gr__ppfft.html#ga43ed3c705881a37820b1d133507dcb1e", null ]
];