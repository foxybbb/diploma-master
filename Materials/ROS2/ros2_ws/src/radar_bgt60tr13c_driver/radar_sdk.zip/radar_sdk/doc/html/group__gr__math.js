var group__gr__math =
[
    [ "ifx_math_db_to_linear", "group__gr__math.html#ga7e2b791eff3da1703b8e2d552097ac96", null ],
    [ "ifx_math_find_max", "group__gr__math.html#ga44066f2859b363a6ffba7aab69c1939d", null ],
    [ "ifx_math_ispower_of_2", "group__gr__math.html#gab07e5b60f93012f05e402b85b11d2509", null ],
    [ "ifx_math_linear_to_db", "group__gr__math.html#ga1284629f988ade5e005ac8cb973639b7", null ],
    [ "ifx_math_round_up_power_of_2_uint32", "group__gr__math.html#ga4677651b27fb8392e3aacd01d22621c7", null ],
    [ "ifx_math_vec_clip_gt_threshold_r", "group__gr__math.html#ga921005e118c124e33f5a77125aa5c099", null ],
    [ "ifx_math_vec_clip_lt_threshold_r", "group__gr__math.html#gae4e672a84e7345cb8fb18ba6f0956088", null ]
];