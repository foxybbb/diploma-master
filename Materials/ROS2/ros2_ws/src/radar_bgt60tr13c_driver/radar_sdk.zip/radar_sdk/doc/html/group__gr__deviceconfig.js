var group__gr__deviceconfig =
[
    [ "ifx_devconf_count_rx_antennas", "group__gr__deviceconfig.html#ga34dff39dd92cfc04df275440d3128378", null ],
    [ "ifx_devconf_get_bandwidth", "group__gr__deviceconfig.html#ga41bb1322bbc6e36a970f129251d609b3", null ],
    [ "ifx_devconf_get_center_frequency", "group__gr__deviceconfig.html#gace9fa4d4a4469521afc421638f5df496", null ],
    [ "ifx_devconf_get_chirp_time", "group__gr__deviceconfig.html#ga8d93822fc90b5ae923a8e457a67262dc", null ]
];