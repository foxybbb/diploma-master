var group__gr__types =
[
    [ "ifx_Complex_s", "structifx___complex__s.html", [
      [ "data", "structifx___complex__s.html#a534748ee20ea51d3201a1d3ef34574d3", null ]
    ] ],
    [ "ifx_Polar_s", "structifx___polar__s.html", [
      [ "angle", "structifx___polar__s.html#aca49efab93f478d86316c1a7c46d1070", null ],
      [ "radius", "structifx___polar__s.html#a9057f3cfe5bc97d4def1a8c06c620153", null ]
    ] ],
    [ "ifx_Complex_t", "group__gr__types.html#gaeab2d3ab8cca4b10be697dab9a3dfc2c", null ],
    [ "ifx_Polar_t", "group__gr__types.html#gaa24c2c1cc332d296371b6b2cfea0843f", null ]
];