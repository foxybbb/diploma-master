var group__gr__sa =
[
    [ "ifx_spectrum_axis_calc_beat_freq_axis", "group__gr__sa.html#ga76e45d282ef44a07304e23199f33c143", null ],
    [ "ifx_spectrum_axis_calc_beat_freq_per_bin", "group__gr__sa.html#gad3df91f76d8b44c00b40b1d5fc6c0617", null ],
    [ "ifx_spectrum_axis_calc_dist_per_bin", "group__gr__sa.html#gac1b4b93135b25437dd39405c2e89cfba", null ],
    [ "ifx_spectrum_axis_calc_range_axis", "group__gr__sa.html#gae1625c24c092b186a8eeb533750a4cb6", null ],
    [ "ifx_spectrum_axis_calc_sampling_freq_axis", "group__gr__sa.html#gacf367343a33ed486df965c7429f3d154", null ],
    [ "ifx_spectrum_axis_calc_speed_axis", "group__gr__sa.html#ga759ea7d56558ab987fc8caec2ba2c00b", null ],
    [ "ifx_spectrum_axis_calc_speed_per_bin", "group__gr__sa.html#ga545d9eafaf33c956c894d69405833444", null ]
];