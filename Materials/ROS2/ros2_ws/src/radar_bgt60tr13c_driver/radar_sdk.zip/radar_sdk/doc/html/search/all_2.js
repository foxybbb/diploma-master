var searchData=
[
  ['band_41',['band',['../structifx___mimose___a_f_c___control__t.html#ac79b6bd634961b7a00ddd846e9bf883e',1,'ifx_Mimose_AFC_Control_t']]],
  ['bandwidth_5fhz_42',['bandwidth_Hz',['../structifx___segmentation___config__t.html#a6163a25c93a29a795341cd15200779c1',1,'ifx_Segmentation_Config_t']]],
  ['base_20_28ifxbase_29_43',['Base (ifxBase)',['../group__gr__cat___s_d_k__base.html',1,'']]],
  ['base_2eh_44',['Base.h',['../_base_8h.html',1,'']]],
  ['bgt60ltr11_20doppler_20radar_20sensors_20_28ifxltr11_29_45',['BGT60LTR11 Doppler Radar Sensors (ifxLtr11)',['../group__gr__cat__device__ltr11.html',1,'']]],
  ['board_5ftype_46',['board_type',['../structifx___radar___sensor___list___entry__t.html#a5d451506064e43edc413517d1378fa5f',1,'ifx_Radar_Sensor_List_Entry_t']]],
  ['building_20sdk_20from_20source_20code_47',['Building SDK from source code',['../pg_radarsdk_setup_build_environment.html',1,'']]]
];
