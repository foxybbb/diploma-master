var searchData=
[
  ['log10_2921',['LOG10',['../_defines_8h.html#a386bc1bec332d5809e3c5e5be1f47a5d',1,'Defines.h']]],
  ['log1p_2922',['LOG1P',['../_defines_8h.html#afb5798a2d57b769a1f77ef259f361f5c',1,'Defines.h']]],
  ['logn_2923',['LOGN',['../_defines_8h.html#aa7c39f30636a35aaebd2dcdc04d9d8fd',1,'Defines.h']]]
];
