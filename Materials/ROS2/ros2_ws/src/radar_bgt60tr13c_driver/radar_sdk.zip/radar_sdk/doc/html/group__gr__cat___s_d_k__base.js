var group__gr__cat___s_d_k__base =
[
    [ "Complex", "group__gr__complex.html", "group__gr__complex" ],
    [ "Cube", "group__gr__cube.html", "group__gr__cube" ],
    [ "Error", "group__gr__error.html", "group__gr__error" ],
    [ "Linear Algebra", "group__gr__la.html", "group__gr__la" ],
    [ "List", "group__gr__list.html", "group__gr__list" ],
    [ "Log", "group__gr__log.html", "group__gr__log" ],
    [ "Math", "group__gr__math.html", "group__gr__math" ],
    [ "Matrix", "group__gr__matrix.html", "group__gr__matrix" ],
    [ "Multi-dimensional arrays", "group__gr__mda.html", "group__gr__mda" ],
    [ "Memory", "group__gr__mem.html", "group__gr__mem" ],
    [ "Types", "group__gr__types.html", "group__gr__types" ],
    [ "Vector", "group__gr__vector.html", "group__gr__vector" ],
    [ "Version", "group__gr__sdk__version.html", "group__gr__sdk__version" ]
];