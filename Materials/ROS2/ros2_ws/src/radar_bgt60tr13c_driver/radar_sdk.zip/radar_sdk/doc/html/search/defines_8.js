var searchData=
[
  ['pow_2927',['POW',['../_defines_8h.html#a7d36eb793ee8943f856044317659fbf1',1,'Defines.h']]]
];
