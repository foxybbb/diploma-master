var group__gr__anglemonopulse =
[
    [ "ifx_anglemonopulse_create", "group__gr__anglemonopulse.html#ga48893bb2cd2eacd8ba63c2e97d0a8d51", null ],
    [ "ifx_anglemonopulse_destroy", "group__gr__anglemonopulse.html#ga4c8ca24767fe85f68b2d1258716d3250", null ],
    [ "ifx_anglemonopulse_get_antenna_spacing", "group__gr__anglemonopulse.html#gacc5987d1a213f17c676ac9f03f068509", null ],
    [ "ifx_anglemonopulse_get_wavelength", "group__gr__anglemonopulse.html#ga5f3d86d6cbc5ae9f00093fa8630ed6e0", null ],
    [ "ifx_anglemonopulse_scalar_run", "group__gr__anglemonopulse.html#ga9827e9002adb407ef8acf29ca87f4245", null ],
    [ "ifx_anglemonopulse_set_antenna_spacing", "group__gr__anglemonopulse.html#ga73b969f4749a733de9cb6af1516988c6", null ],
    [ "ifx_anglemonopulse_set_wavelength", "group__gr__anglemonopulse.html#ga9f2bdc50e40791537d29184bb14f1e76", null ],
    [ "ifx_anglemonopulse_vector_run", "group__gr__anglemonopulse.html#ga3e92140b40c456e1b2f540198f87aba9", null ]
];