var group__gr__doppler__spect =
[
    [ "ifx_doppler_spectrogram_create", "group__gr__doppler__spect.html#ga5029ab1d3d3afe5c51cd821eb5cded56", null ],
    [ "ifx_doppler_spectrogram_destroy", "group__gr__doppler__spect.html#ga850a6b5f9d9cb346abcd06b5decc2524", null ],
    [ "ifx_doppler_spectrogram_get_threshold", "group__gr__doppler__spect.html#ga8983fd46a73781901f8376840ddb06f8", null ],
    [ "ifx_doppler_spectrogram_run_cr", "group__gr__doppler__spect.html#gaf3e80e48a92cb1f2c174db8b43d633b2", null ],
    [ "ifx_doppler_spectrogram_run_r", "group__gr__doppler__spect.html#gaee2964ae9ce248c2d64cee16120167fc", null ],
    [ "ifx_doppler_spectrogram_set_threshold", "group__gr__doppler__spect.html#ga16c7acec3ae44c6dafbcb26ede15b8cd", null ]
];