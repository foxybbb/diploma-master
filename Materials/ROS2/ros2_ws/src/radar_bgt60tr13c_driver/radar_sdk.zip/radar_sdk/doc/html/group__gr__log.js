var group__gr__log =
[
    [ "ifx_log", "group__gr__log.html#gadea3ac7d04815112795fd45eaae92db9", null ]
];