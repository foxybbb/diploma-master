var searchData=
[
  ['uuid_5fstring_5fsize_2941',['UUID_STRING_SIZE',['../_radar_device_common_8h.html#a35086c943ccfbec23540722f0bec1af9',1,'RadarDeviceCommon.h']]]
];
