var group__gr__cat___s_d_k__comport =
[
    [ "ifx_comport_close", "group__gr__cat___s_d_k__comport.html#gab31c85b1026c713f9bfd05bc4ca2637c", null ],
    [ "ifx_comport_get_data", "group__gr__cat___s_d_k__comport.html#gac92407429892f4677c6e55919a28e5a7", null ],
    [ "ifx_comport_get_list", "group__gr__cat___s_d_k__comport.html#gae85facb362c27b78c7a7b55508420990", null ],
    [ "ifx_comport_open", "group__gr__cat___s_d_k__comport.html#ga104dc93cdfeac64db80f8b9885e25c7a", null ],
    [ "ifx_comport_send_data", "group__gr__cat___s_d_k__comport.html#ga4213c3cb4b055da9a5214dd2cb04cfde", null ],
    [ "ifx_comport_set_timeout", "group__gr__cat___s_d_k__comport.html#gab58e1170f6b901b0aca6e71e66981e6c", null ]
];