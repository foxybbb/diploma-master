var group__gr__cube =
[
    [ "ifx_cube_clear_c", "group__gr__cube.html#gaa5bbea513575e9945a54a1480dc8c22a", null ],
    [ "ifx_cube_clear_r", "group__gr__cube.html#gabfa3013c3f4533db615b5439aadf19a7", null ],
    [ "ifx_cube_clone_c", "group__gr__cube.html#ga46c3d4c94f478869bbe4d1c1dc46df87", null ],
    [ "ifx_cube_clone_r", "group__gr__cube.html#gaa41db3f7d027ea4d64ec6096c5960077", null ],
    [ "ifx_cube_col_abs_r", "group__gr__cube.html#ga3f469a7275e7735c0943a2b3218be646", null ],
    [ "ifx_cube_copy_c", "group__gr__cube.html#ga67021a19e6d9a0b6a32c39b50fcfe889", null ],
    [ "ifx_cube_copy_r", "group__gr__cube.html#ga88b1e7d6da8cf2cd328a30e8f4196868", null ],
    [ "ifx_cube_create_c", "group__gr__cube.html#ga1cba778c0d00b6ed690c8ccf3cb7b20d", null ],
    [ "ifx_cube_create_r", "group__gr__cube.html#ga2b2005f0f0712352efa982beaa8b1fbf", null ],
    [ "ifx_cube_destroy_c", "group__gr__cube.html#gaec1d60b7c070a437070a889ea88f0d38", null ],
    [ "ifx_cube_destroy_r", "group__gr__cube.html#gad789919d93d97fe1cc33db56c6ac02d3", null ],
    [ "ifx_cube_get_col_c", "group__gr__cube.html#ga70a9b3634011ed5c9a59d50b024effb8", null ],
    [ "ifx_cube_get_col_r", "group__gr__cube.html#gafd1bb913eed8775df40800bd025a7ed2", null ],
    [ "ifx_cube_get_row_c", "group__gr__cube.html#ga17ac759b50fab183dc85696802bd1e52", null ],
    [ "ifx_cube_get_row_r", "group__gr__cube.html#ga115b1b21815aa2b4c259471da4a268dd", null ],
    [ "ifx_cube_get_slice_c", "group__gr__cube.html#ga98bd7811bea77a15012115dded1e4e3a", null ],
    [ "ifx_cube_get_slice_r", "group__gr__cube.html#ga807f1a0ca82f203cca5450d6e5ba293d", null ]
];