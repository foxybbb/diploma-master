var group__gr__cat___avian =
[
    [ "Device Configuration", "group__gr__deviceconfig.html", "group__gr__deviceconfig" ],
    [ "Device Control", "group__gr__devicecontrol.html", "group__gr__devicecontrol" ],
    [ "Metrics", "group__gr__avian__metrics.html", "group__gr__avian__metrics" ]
];