var group__gr__avian__metrics =
[
    [ "ifx_Avian_Metrics_t", "group__gr__avian__metrics.html#gab7a5a31c86c9fd7c963c30000c6f89d5", null ],
    [ "ifx_avian_metrics_from_config", "group__gr__avian__metrics.html#gaaf92c814b1dace9ce0b08e3353606dba", null ],
    [ "ifx_avian_metrics_to_config", "group__gr__avian__metrics.html#ga5c6fec106ba458932b736004e75408c6", null ]
];