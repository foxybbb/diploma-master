var group__gr__sdk__version =
[
    [ "ifx_sdk_get_version_hash", "group__gr__sdk__version.html#gae2522c797b03283935d114fa6cb60db2", null ],
    [ "ifx_sdk_get_version_string", "group__gr__sdk__version.html#ga17d10e899297f7d1b84d8de056f1fc00", null ],
    [ "ifx_sdk_get_version_string_full", "group__gr__sdk__version.html#gac60ea0df548de6cc3a1ed92c6a8be200", null ]
];