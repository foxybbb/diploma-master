var group__gr__cat___radar_presence =
[
    [ "ifx_Presence_Sensing_Config_t", "structifx___presence___sensing___config__t.html", [
      [ "max_detection_range_m", "structifx___presence___sensing___config__t.html#a546a1924db816c00272aac8b1e6c053b", null ],
      [ "min_detection_range_m", "structifx___presence___sensing___config__t.html#ab105a8faf3c85c2f0a6fd9d42f212e91", null ],
      [ "sensitivity_threshold", "structifx___presence___sensing___config__t.html#ace66b68ce9859c7ac4bae13abcf98722", null ]
    ] ],
    [ "ifx_Presence_Sensing_Result_t", "structifx___presence___sensing___result__t.html", [
      [ "target_distance_m", "structifx___presence___sensing___result__t.html#a1bbb02105727f1736f7b9cd71182cf5d", null ],
      [ "target_state", "structifx___presence___sensing___result__t.html#a25f2f5bb491e530f93f2890de8c88703", null ]
    ] ],
    [ "ifx_Presence_Sensing_t", "group__gr__cat___radar_presence.html#ga8801fc48b7e05432d206208d2fe0fc52", null ],
    [ "ifx_presence_sensing_create", "group__gr__cat___radar_presence.html#ga01428c2fc765716eaf7e6dbd17055abf", null ],
    [ "ifx_presence_sensing_destroy", "group__gr__cat___radar_presence.html#ga69ce081e1181602a6fbeb301a1db1abb", null ],
    [ "ifx_presence_sensing_get_config_defaults", "group__gr__cat___radar_presence.html#ga5e2212c37172857c1696e36b3dccf485", null ],
    [ "ifx_presence_sensing_run", "group__gr__cat___radar_presence.html#ga172b3ca87629d83283fdb92e3d527529", null ]
];