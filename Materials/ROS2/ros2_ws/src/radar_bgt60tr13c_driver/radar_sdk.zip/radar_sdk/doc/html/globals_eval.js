var globals_eval =
[
    [ "i", "globals_eval.html", null ],
    [ "n", "globals_eval_n.html", null ],
    [ "p", "globals_eval_p.html", null ],
    [ "t", "globals_eval_t.html", null ]
];