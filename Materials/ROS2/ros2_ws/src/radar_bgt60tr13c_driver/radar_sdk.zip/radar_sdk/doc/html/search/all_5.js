var searchData=
[
  ['enable_5finterference_5fmitigation_111',['enable_interference_mitigation',['../structifx___advanced___motion___sensing___config__t.html#a4441ae8b10a77297aa8ed8aa82f62a85',1,'ifx_Advanced_Motion_Sensing_Config_t']]],
  ['end_5ffrequency_5fhz_112',['end_frequency_Hz',['../structifx___avian___config__t.html#abc48628dc384bc53dd91e712a9233a95',1,'ifx_Avian_Config_t::end_frequency_Hz()'],['../structifx___fmcw___sequence___chirp.html#a27758dc1f232f1a2bb2e4ce19b469f03',1,'ifx_Fmcw_Sequence_Chirp::end_frequency_Hz()']]],
  ['error_113',['Error',['../group__gr__error.html',1,'']]],
  ['error_2eh_114',['Error.h',['../_error_8h.html',1,'']]],
  ['example_20applications_115',['Example applications',['../pg_radarsdk_applications.html',1,'']]],
  ['exp_116',['EXP',['../_defines_8h.html#a179978530f93b1e13bc48dc40dc1960e',1,'Defines.h']]],
  ['extendedversion_117',['extendedVersion',['../structifx___firmware___info__t.html#a7ee3344f7f3462a575011c266e07e86e',1,'ifx_Firmware_Info_t']]]
];
