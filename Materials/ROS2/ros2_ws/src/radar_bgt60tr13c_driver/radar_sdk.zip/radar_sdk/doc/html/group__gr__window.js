var group__gr__window =
[
    [ "ifx_window_init", "group__gr__window.html#gaab5b1dbddc3a3cf9fef19f2b51adc0b2", null ]
];