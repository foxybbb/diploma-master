var searchData=
[
  ['orientation_1367',['orientation',['../structifx___segmentation___config__t.html#acb9b8e7284c0ac7039b64579f7f64854',1,'ifx_Segmentation_Config_t']]],
  ['os_2dcfar_1368',['OS-CFAR',['../group__gr__oscfar.html',1,'']]],
  ['oscfar_2eh_1369',['OSCFAR.h',['../_o_s_c_f_a_r_8h.html',1,'']]],
  ['output_5fscale_5ftype_1370',['output_scale_type',['../structifx___r_d_m___config__t.html#a6200b1d8b751865039606fd615603c1d',1,'ifx_RDM_Config_t::output_scale_type()'],['../structifx___r_s___config__t.html#a6200b1d8b751865039606fd615603c1d',1,'ifx_RS_Config_t::output_scale_type()']]],
  ['oversampling_5ffactor_1371',['oversampling_factor',['../structifx___cw___adc___config__t.html#a22362840fc7c2794f0942b3709275876',1,'ifx_Cw_Adc_Config_t']]]
];
