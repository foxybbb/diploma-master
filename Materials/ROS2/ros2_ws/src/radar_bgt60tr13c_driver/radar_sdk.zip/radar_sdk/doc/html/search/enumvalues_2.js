var searchData=
[
  ['potential_5ftarget_5fdetected_2755',['POTENTIAL_TARGET_DETECTED',['../group__gr__cat___motion_sensing.html#ggaea1d7d9131435752f7c92af8c12de1d9a16d13cce81f1d81e4c8465b2b5ca6c35',1,'AdvancedMotionSensing.h']]]
];
